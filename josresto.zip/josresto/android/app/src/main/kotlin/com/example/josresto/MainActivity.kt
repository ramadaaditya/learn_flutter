package com.example.josresto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
